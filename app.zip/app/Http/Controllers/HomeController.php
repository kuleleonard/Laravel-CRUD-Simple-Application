<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Home;
use Illuminate\Support\Facades\DB;

class HomeController extends Controller
{
    public function home(){
        $Home = new Home;
        $users = $Home->all();
        return view('frontend.home', ['users' => $users]);
    }

    public function create(){
        $Home = new Home;
        $users = $Home->all();
        return view('frontend.create', ['users' => $users]);
    }

    public function add(Request $request){
        //validator(['blog_pagetitle']);
        $Home = new Home();
        $Home->first_name = $request->input('first_name');
        $Home->last_name = $request->input('last_name');
        $Home->email_address = $request->input('email_address');
        $Home->phone_number = $request->input('phone_number');
        $Home->save();

        return redirect()->route('frontend.home');
    }

     //Edit
     public function edit(Request $request){

        $user_id = $request->user_id;
        $Home = new Home();
        $users  = $Home->where(['user_id' => $user_id])->first();

        //$TutajuaBlogs = new TutajuaBlogs;

       // $TutajuaBlogs = $TutajuaBlogs->all();
        return view('frontend.edit',['users' =>$users]);

}

public function update(Request $request)
    {
        $user_id = $request->user_id;

                $first_name = $request->first_name;
                $last_name = $request->last_name;
                $email_address = $request->email_address;
                $phone_number = $request->phone_number;

                Home::where('user_id', $user_id)->update([
                'first_name' => $first_name,
                'last_name' => $last_name,
                'email_address' => $email_address,
                'phone_number' => $phone_number,

        ]);

        return redirect()->route('frontend.home')->with('success', 'Blog updated successfully!');
    }

     // Delete
   public function delete(Request $request)
   {

        $user_id = $request->user_id;
        DB::table('project_users')->where('user_id', $user_id)->delete();
        return redirect()->route('frontend.home', ['user_id' => $user_id])->with('success', 'Blog updated successfully!');
   }

}
