Who are we the coders
<?php /**PATH C:\wamp64\www\project1\resources\views/frontend/about.blade.php ENDPATH**/ ?>