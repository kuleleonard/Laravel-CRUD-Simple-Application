<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-12 mt-5">
            <div class="card-header">
                <span class="h4">Edit User

                </span>
                    <div class="card-body">

                        <form action="<?php echo e(route('frontend.update', ['user_id' => $users->user_id])); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>


                            <div class="mb-3">
                                <label for="exampleInputEmail1" class="form-label">First Name</label>
                                <input type="text" name="first_name" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo e($users->first_name); ?>">
                                </div>

                                <div class="mb-3">
                                    <label for="exampleInputEmail1" class="form-label">Last Name</label>
                                    <input type="text" name="last_name" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo e($users->last_name); ?>">
                                    </div>

                                    <div class="mb-3">
                                        <label for="exampleInputEmail1" class="form-label">Email Address</label>
                                        <input type="email" name="email_address" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo e($users->email_address); ?>">
                                        </div>


                                    <div class="mb-3">
                                        <label for="exampleInputEmail1" class="form-label">Phone Number</label>
                                        <input type="text" name="phone_number" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo e($users->phone_number); ?>">
                                        </div>


                            <button type="submit" class="btn btn-primary">Submit</button>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>

  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\project1\resources\views/frontend/edit.blade.php ENDPATH**/ ?>