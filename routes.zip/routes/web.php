<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\AboutController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

/* Custom routes */

// Home
Route::get('home', [HomeController::class, 'home'])->name('frontend.home');

// Create
Route::get('create', [HomeController::class, 'create'])->name('frontend.create');

// Add
Route::post('add', [HomeController::class, 'add'])->name('frontend.add');

// Edit
Route::get('edit', [HomeController::class, 'edit'])->name('frontend.edit');

// Update
Route::put('edit', [HomeController::class, 'update'])->name('frontend.update');

// Delete
Route::delete('delete', [HomeController::class, 'delete'])->name('frontend.delete');

// About
Route::get('about-us', [AboutController::class, 'about'])->name('frontend.about');
