Who are we the coders
